__version__ = '0.2.1'

#change log:
# 0.0.0: first version
# 0.0.1: transcribe added for current models
# 0.0.2: timestamps/pause calculations added for current models
# 0.0.3: WER/CER metrics added
# 0.0.4: download checkpoints from GCP added
# 0.0.5: download checkpoints from hugging face for w2v2
# 0.1.0: classification models added
# 0.2.0: word vector similarity addeded
# 0.2.1: fixed embedding extraction