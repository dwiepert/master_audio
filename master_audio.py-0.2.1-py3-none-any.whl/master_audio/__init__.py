from ._version import __version__ as _version
__version__ = _version